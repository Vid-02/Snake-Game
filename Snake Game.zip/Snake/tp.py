N = [1,2,3,4]
if N==0:
    print("Under flow")
else:
    print("Ok")